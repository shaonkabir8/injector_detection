# Semgrep Report

Generated: Fri Jun  5 11:27:10 PM +06 2026

               
               
┌─────────────┐
│ Scan Status │
└─────────────┘
  Scanning 13131 files tracked by git with 1059 Code rules:
                                                                                
  Language      Rules   Files          Origin      Rules                        
 ─────────────────────────────        ───────────────────                       
  <multilang>      60   18736          Community    1059                        
  python          243    3473                                                   
  c                 5      44                                                   
  json              4      34                                                   
  yaml             31      29                                                   
  js              153      15                                                   
  bash              4       2                                                   
  dockerfile        6       1                                                   
  html              1       1                                                   
                                                                                
Loop <_UnixSelectorEventLoop running=False closed=True debug=False> that handles pid 48862 is closed
Exception ignored in: <function BaseSubprocessTransport.__del__ at 0x7eb36e51d750>
Traceback (most recent call last):
  File "/usr/lib/python3.10/asyncio/base_subprocess.py", line 126, in __del__
    self.close()
  File "/usr/lib/python3.10/asyncio/base_subprocess.py", line 104, in close
    proto.pipe.close()
  File "/usr/lib/python3.10/asyncio/unix_events.py", line 547, in close
    self._close(None)
  File "/usr/lib/python3.10/asyncio/unix_events.py", line 571, in _close
    self._loop.call_soon(self._call_connection_lost, exc)
  File "/usr/lib/python3.10/asyncio/base_events.py", line 753, in call_soon
    self._check_closed()
  File "/usr/lib/python3.10/asyncio/base_events.py", line 515, in _check_closed
    raise RuntimeError('Event loop is closed')
RuntimeError: Event loop is closed
