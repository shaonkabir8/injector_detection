routers/queue.py:20:from fastapi import APIRouter, File, Form, HTTPException, UploadFile, status
routers/queue.py:28:router = APIRouter(tags=["queue"])
routers/queue.py:33:@router.post(
routers/queue.py:148:@router.get(
routers/queue.py:171:@router.get(
routers/queue.py:186:@router.get(
routers/queue.py:202:@router.post(
routers/detect.py:31:from fastapi import APIRouter, File, Form, HTTPException, UploadFile, status
routers/detect.py:59:router = APIRouter(tags=["detection"])
routers/detect.py:161:@router.post(
routers/detect.py:191:@router.post(
routers/detect.py:230:@router.post(
routers/detect.py:267:@router.post(
routers/detect.py:286:@router.post(
routers/detect.py:376:@router.post(
routers/detect.py:460:@router.get(
routers/detect.py:469:@router.post(
routers/health.py:1:from fastapi import APIRouter
routers/health.py:4:router = APIRouter()
routers/health.py:13:@router.get("/healthz", response_model=HealthResponse, tags=["health"])
routers/video.py:24:from fastapi import APIRouter, File, Form, HTTPException, UploadFile, status
routers/video.py:29:router = APIRouter(tags=["video"])
routers/video.py:37:@router.post(
routers/video.py:132:@router.post(
routers/video.py:218:@router.post(
routers/video.py:294:@router.post(
routers/audit.py:1:from fastapi import APIRouter
routers/audit.py:4:router = APIRouter(tags=["audit"])
routers/audit.py:6:@router.get("/audit/summary", summary="Root Admin Reporting - System Summary")
routers/audit.py:17:@router.post("/audit/log", summary="Log an internal audit event manually")
routers/feedback.py:20:from fastapi import APIRouter, File, Form, HTTPException, UploadFile, status
routers/feedback.py:26:router = APIRouter(tags=["feedback"])
routers/feedback.py:29:@router.post(
routers/feedback.py:84:@router.get(
routers/feedback.py:95:@router.get(
routers/feedback.py:109:@router.get(
