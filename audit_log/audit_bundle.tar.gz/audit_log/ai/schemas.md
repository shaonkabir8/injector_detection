schemas/detection.py
schemas/__pycache__/__init__.cpython-312.pyc
schemas/__pycache__/detection.cpython-312.pyc
schemas/__init__.py
