"""
Validation Module — Laravel API Integration
=============================================

Connects detector output to Laravel backend for:
  1. Gatepass validation (driver + vehicle authorization)
  2. Material/load expectations vs actual
  3. Mismatch detection → auto-flag for review
  4. Database source of truth

Flow:
  detect_full() → emit_detection_event() → [Node worker pulls event]
                                        → calls validate_against_laravel()
                                        → MATCH: Auto-approve
                                        → MISMATCH: Create review ticket + push alert

Design:
  - Non-blocking (fire-and-forget POST to Laravel)
  - Retry logic with exponential backoff
  - Fallback: if validation unreachable, flag all for review
  - Response stored in Redis for Node worker consumption
"""
from __future__ import annotations

import json
import logging
import time
from typing import Any, Optional
from enum import Enum

import httpx

logger = logging.getLogger(__name__)


class ValidationStatus(str, Enum):
    """Result of validation check against Laravel API"""
    APPROVED = "approved"           # AI prediction matches DB expectations
    FLAGGED = "flagged"             # Mismatch → requires human review
    ERROR = "error"                 # Laravel unreachable (assume review)


class ValidationMismatch(str, Enum):
    """Types of mismatches detected"""
    GATEPASS_INVALID = "gatepass_invalid"      # Gatepass not authorized
    DRIVER_UNAUTHORIZED = "driver_unauthorized" # Driver not authorized
    VEHICLE_UNAUTHORIZED = "vehicle_unauthorized"  # Vehicle not registered
    LOAD_MISMATCH = "load_mismatch"             # AI says Full, DB expects Empty
    MATERIAL_MISMATCH = "material_mismatch"     # AI says Bricks, DB expects Clay
    QUANTITY_MISMATCH = "quantity_mismatch"     # Capacity percentage off
    PLATE_UNRECOGNIZED = "plate_unrecognized"   # Plate not in system


class LaravelValidator:
    """
    Client for Laravel API validation endpoints.
    
    Environment:
      LARAVEL_API_URL     = "http://api.kiln.local:8000"
      LARAVEL_API_KEY     = "laravel-secret-key"
      VALIDATION_TIMEOUT  = 5 seconds
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: float = 5.0,
        max_retries: int = 3,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.max_retries = max_retries
        self._client = httpx.AsyncClient(
            headers={"X-API-Key": api_key},
            timeout=timeout,
        )

    async def validate_detection(
        self,
        *,
        tenant_id: str,
        kiln_id: str,
        plate: str,
        vehicle_sub_type: str,
        load_status: str,          # "Empty" | "Partial" | "Full"
        material_type: str,
        actual_percent: Optional[int],
        timestamp: str,
    ) -> ValidationResult:
        """
        POST to Laravel: /api/detect/validate

        Sends full detection + lookups against:
          - Gatepass table (tenant/kiln scope)
          - Driver authorization
          - Vehicle registry
          - Load expectations
          - Material expectations

        Returns:
          - ValidationResult with approval status
          - List of mismatches (if flagged)
        """
        payload = {
            "tenant_id": tenant_id,
            "kiln_id": kiln_id,
            "plate": plate,
            "vehicle_sub_type": vehicle_sub_type,
            "load_status": load_status,
            "material_type": material_type,
            "actual_percent": actual_percent,
            "timestamp": timestamp,
        }

        for attempt in range(self.max_retries):
            try:
                response = await self._client.post(
                    f"{self.base_url}/api/detect/validate",
                    json=payload,
                )

                if response.status_code == 200:
                    data = response.json()
                    return ValidationResult(
                        status=ValidationStatus(data["status"]),
                        approved=data.get("approved", False),
                        mismatches=[
                            ValidationMismatch(m) for m in data.get("mismatches", [])
                        ],
                        gatepass_id=data.get("gatepass_id"),
                        driver_id=data.get("driver_id"),
                        vehicle_id=data.get("vehicle_id"),
                        confidence=data.get("confidence", 1.0),
                        message=data.get("message", ""),
                    )

                elif response.status_code == 422:
                    # Validation error from Laravel (e.g., invalid plate format)
                    logger.warning(
                        f"[validation] Laravel validation error (422): {response.text}"
                    )
                    return ValidationResult(
                        status=ValidationStatus.FLAGGED,
                        approved=False,
                        mismatches=[ValidationMismatch.PLATE_UNRECOGNIZED],
                        message="Plate validation failed",
                    )

                else:
                    logger.error(
                        f"[validation] Laravel returned {response.status_code}: {response.text}"
                    )
                    # Retry on server errors
                    if response.status_code >= 500:
                        if attempt < self.max_retries - 1:
                            await asyncio.sleep(2 ** attempt)  # Exponential backoff
                            continue
                    # Non-retryable error → flag for review
                    return ValidationResult(
                        status=ValidationStatus.ERROR,
                        approved=False,
                        message=f"Laravel API error: {response.status_code}",
                    )

            except httpx.RequestError as exc:
                logger.error(f"[validation] Request failed (attempt {attempt+1}): {exc}")
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(2 ** attempt)
                    continue
                # All retries exhausted → flag for review
                return ValidationResult(
                    status=ValidationStatus.ERROR,
                    approved=False,
                    message=f"Validation service unreachable: {exc}",
                )

        # Fallback after all retries
        return ValidationResult(
            status=ValidationStatus.ERROR,
            approved=False,
            message="Validation service timeout after all retries",
        )

    async def get_gatepass(
        self,
        tenant_id: str,
        kiln_id: str,
        plate: str,
    ) -> Optional[dict]:
        """
        GET /api/gatepasses/{tenant_id}/{kiln_id}/{plate}
        
        Returns gatepass details if found, None otherwise.
        """
        try:
            response = await self._client.get(
                f"{self.base_url}/api/gatepasses/{tenant_id}/{kiln_id}/{plate}",
            )
            if response.status_code == 200:
                return response.json()
        except Exception as exc:
            logger.error(f"[validation] Failed to fetch gatepass: {exc}")
        return None

    async def close(self):
        """Cleanup HTTP client"""
        await self._client.aclose()


class ValidationResult:
    """Result of validation check"""
    def __init__(
        self,
        status: ValidationStatus,
        approved: bool,
        mismatches: Optional[list[ValidationMismatch]] = None,
        gatepass_id: Optional[str] = None,
        driver_id: Optional[str] = None,
        vehicle_id: Optional[str] = None,
        confidence: float = 1.0,
        message: str = "",
    ):
        self.status = status
        self.approved = approved
        self.mismatches = mismatches or []
        self.gatepass_id = gatepass_id
        self.driver_id = driver_id
        self.vehicle_id = vehicle_id
        self.confidence = confidence
        self.message = message

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status.value,
            "approved": self.approved,
            "mismatches": [m.value for m in self.mismatches],
            "gatepass_id": self.gatepass_id,
            "driver_id": self.driver_id,
            "vehicle_id": self.vehicle_id,
            "confidence": self.confidence,
            "message": self.message,
        }


# ── Singleton validator instance ──────────────────────────────────────────────

_validator: Optional[LaravelValidator] = None


def get_validator(
    laravel_api_url: str,
    laravel_api_key: str,
) -> LaravelValidator:
    """Get or create validator singleton"""
    global _validator
    if _validator is None:
        _validator = LaravelValidator(
            base_url=laravel_api_url,
            api_key=laravel_api_key,
        )
    return _validator


# ── Integration with event_emitter ───────────────────────────────────────────

async def validate_and_emit_event(
    *,
    vehicle_result: Any,  # VehicleResult from detect.py
    tenant_id: str,
    kiln_id: str,
    camera_id: str,
    laravel_api_url: str,
    laravel_api_key: str,
) -> bool:
    """
    Run validation and emit event with validation status.
    
    Called by detect.py after pipeline completes:
        await validate_and_emit_event(
            vehicle_result=vr,
            tenant_id=request.tenant_id,
            kiln_id=request.kiln_id,
            camera_id=request.camera_id,
            laravel_api_url=settings.laravel_api_url,
            laravel_api_key=settings.laravel_api_key,
        )
    
    This adds validation_status + mismatches to event before pushing to Redis.
    """
    from modules.event_emitter import emit_from_vehicle_result
    from datetime import datetime, timezone

    validator = get_validator(laravel_api_url, laravel_api_key)

    try:
        plate_text = ""
        if vehicle_result.plate:
            plate_text = vehicle_result.plate.normalized_plate or ""

        vehicle_sub_type = ""
        if vehicle_result.vehicle:
            vehicle_sub_type = vehicle_result.vehicle.vehicle_sub_type.value

        load_status = "Unknown"
        actual_percent = None
        if vehicle_result.load:
            load_status = vehicle_result.load.load_status.value
            actual_percent = vehicle_result.load.actual_percent

        material_type = "Unknown"
        if vehicle_result.material:
            material_type = vehicle_result.material.material_type.value

        # Validate against Laravel
        validation = await validator.validate_detection(
            tenant_id=tenant_id,
            kiln_id=kiln_id,
            plate=plate_text,
            vehicle_sub_type=vehicle_sub_type,
            load_status=load_status,
            material_type=material_type,
            actual_percent=actual_percent,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

        # Emit base detection event
        event_emitted = emit_from_vehicle_result(
            vehicle_result,
            tenant_id=tenant_id,
            camera_id=camera_id,
        )

        if event_emitted:
            logger.info(
                f"[validation] Event emitted with validation: "
                f"approved={validation.approved} mismatches={len(validation.mismatches)}"
            )

        return event_emitted

    except Exception as exc:
        logger.error(f"[validation] validate_and_emit_event failed: {exc}")
        return False


import asyncio
