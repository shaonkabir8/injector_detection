"""
config.py - UPDATED with tenant context and Laravel integration
"""

import os
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # ── Server ────────────────────────────────────────────────────────────────
    host: str = "0.0.0.0"
    port: int = int(os.environ.get("PORT", 5000))
    log_level: str = "info"
    base_path: str = os.environ.get("BASE_PATH", "/detect")

    # ── YOLO Configuration ────────────────────────────────────────────────────
    yolo_model: str = "yolov8n.pt"
    yolo_confidence: float = 0.25
    yolo_iou: float = 0.45

    # ── Plate Detection ───────────────────────────────────────────────────────
    plate_min_confidence: float = 0.2
    plate_min_width: int = 50
    plate_min_height: int = 15
    plate_aspect_ratio_min: float = 1.5
    plate_aspect_ratio_max: float = 8.0

    # ── Load Detection ────────────────────────────────────────────────────────
    load_iou_threshold: float = 0.10
    load_min_item_confidence: float = 0.20
    load_visual_empty_threshold: float = 0.05
    load_visual_full_threshold: float = 0.40
    load_visual_edge_weight: float = 0.45
    load_visual_color_weight: float = 0.40
    load_visual_blob_weight: float = 0.15
    load_visual_edge_max: float = 0.22
    load_visual_color_max: float = 55.0
    load_visual_blob_max: float = 8.0
    load_visual_skip_bottom: float = 0.22
    load_visual_skip_top: float = 0.05

    max_image_bytes: int = 20 * 1024 * 1024

    # ── Redis Cache ───────────────────────────────────────────────────────────
    # Production: redis://redis-host:6379/0
    # Development: leave empty for fakeredis (in-memory)
    redis_url: str = os.environ.get("REDIS_URL", "")

    # Cache TTL for detection results (seconds)
    cache_result_ttl: int = int(os.environ.get("CACHE_TTL", 900))   # 15 min

    # Job queue TTL (seconds) — how long to keep completed/failed jobs
    job_ttl: int = int(os.environ.get("JOB_TTL", 3600))             # 1 hour

    # Detection events TTL — how long to keep emitted events in queue
    event_ttl: int = int(os.environ.get("EVENT_TTL", 86400))        # 24 hours

    # ── YouTube Live Resolver ────────────────────────────────────────────────
    youtube_resolver_enabled: bool = True
    yt_dlp_timeout_seconds: int = 20
    stream_resolve_cache_ttl: int = 600
    video_source_require_api_key: bool = False

    # ═══════════════════════════════════════════════════════════════════════════
    # NEW: TENANT & VALIDATION INTEGRATION
    # ═══════════════════════════════════════════════════════════════════════════

    # ── Laravel API Integration ───────────────────────────────────────────────
    # Laravel backend for validation (gatepass, driver, vehicle authorization)
    laravel_api_url: str = os.environ.get(
        "LARAVEL_API_URL",
        "http://localhost:8000"
    )
    laravel_api_key: str = os.environ.get("LARAVEL_API_KEY", "")
    laravel_validation_enabled: bool = bool(os.environ.get("LARAVEL_VALIDATION_ENABLED", "1"))
    laravel_validation_timeout: float = float(os.environ.get("LARAVEL_VALIDATION_TIMEOUT", "5.0"))

    # ── Node.js Event Consumer ────────────────────────────────────────────────
    # Node.js service that consumes detection events from Redis
    # and performs validation + alert pushing
    nodejs_event_consumer_enabled: bool = bool(
        os.environ.get("NODEJS_EVENT_CONSUMER_ENABLED", "0")
    )

    # ── Per-Tenant Model Adapters ─────────────────────────────────────────────
    # Model strategy:
    #   - Base YOLO + global confidence gate models
    #   - Per-tenant fine-tuned adapters for vehicle/load/material
    #
    # Directory structure:
    # models/
    #   ├── base/
    #   │   ├── yolov8n.pt (global vehicle detector)
    #   │   └── confidence_gate.onnx (global decision model)
    #   └── tenant_adapters/
    #       ├── kiln-dhaka-01/
    #       │   ├── vehicle_subtype.pkl (kiln-specific vehicle classifier)
    #       │   ├── load_detector.pkl
    #       │   └── material_classifier.pkl
    #       ├── kiln-dhaka-02/
    #       │   └── ...
    #
    # When API receives tenant_id + kiln_id:
    #   1. Load global base models
    #   2. Load tenant-specific adapter if exists
    #   3. Use adapter for all per-vehicle models (E, F, G)
    #   4. Use global for detection + gate (B, C, D, I)

    models_base_dir: str = os.environ.get(
        "MODELS_BASE_DIR",
        "/app/detector/models/base"
    )
    models_tenant_adapters_dir: str = os.environ.get(
        "MODELS_TENANT_ADAPTERS_DIR",
        "/app/detector/models/tenant_adapters"
    )

    # Enable per-tenant model loading (experimental)
    # If disabled: use global models for all tenants
    per_tenant_models_enabled: bool = bool(
        os.environ.get("PER_TENANT_MODELS_ENABLED", "0")
    )

    # ── Alert/Notification System ─────────────────────────────────────────────
    # When validation flags a detection for review:
    #   - Auto-flag the event
    #   - Push alert to tenant admin
    #   - Store in review queue for UI dashboard

    alert_enabled: bool = bool(os.environ.get("ALERT_ENABLED", "1"))

    # Alert service options:
    #   - "webhook": POST to Laravel webhook
    #   - "pusher": Pusher.com real-time channel
    #   - "redis": Redis pub/sub
    alert_service: str = os.environ.get("ALERT_SERVICE", "webhook")

    # Webhook URL for alerts (if alert_service="webhook")
    alert_webhook_url: str = os.environ.get(
        "ALERT_WEBHOOK_URL",
        ""
    )

    # Pusher channel for real-time alerts (if alert_service="pusher")
    pusher_app_key: str = os.environ.get("PUSHER_APP_KEY", "")
    pusher_app_cluster: str = os.environ.get("PUSHER_APP_CLUSTER", "mt1")

    # ── SaaS Limits ───────────────────────────────────────────────────────────
    saas_free_daily_limit: int = int(os.environ.get("SAAS_FREE_DAILY_LIMIT", 100))


settings = Settings()
