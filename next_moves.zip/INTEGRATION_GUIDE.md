# BRICKIFY Event-Driven Architecture Integration Guide

## Overview

```
┌─────────────────┐
│   Detector      │
│   (Python/FA)   │
│  - 9-model pipeline
│  - Event emitter
└────────┬────────┘
         │
         │ Detection events
         │ (non-blocking)
         ▼
┌─────────────────┐
│   Redis Queue   │
│ tenant.kiln.cam │
│  .detect        │
└────────┬────────┘
         │
         │ Event listener
         ▼
┌─────────────────┐
│  Node.js        │
│  Validation     │
│  Worker         │
│ - Calls Laravel │
│ - Validates     │
│ - Flags/Alerts  │
└────────┬────────┘
         │
         │ Validation result
         ▼
┌─────────────────┐
│  Laravel API    │
│  - Gatepass DB  │
│  - Driver auth  │
│  - Vehicle reg  │
│  - Review queue │
└─────────────────┘
```

---

## Part 1: Detector Setup (Python)

### 1.1 Install Updated Modules

Copy these files to your detector:

```bash
# Replace existing files
cp /path/to/config_updated.py        detector/config.py
cp /path/to/modules_validation.py    detector/modules/validation.py

# Merge detect_full_updated.py into routers/detect.py
#   (See merge instructions below)
```

### 1.2 Update Dependencies

```bash
# Add to detector/requirements.txt
httpx>=0.24.0          # Async HTTP client for Laravel API calls
```

### 1.3 Environment Variables (`.env`)

```bash
# Redis (required for event queuing)
REDIS_URL=redis://redis:6379/0
EVENT_TTL=86400                    # Keep events for 24 hours

# Laravel API
LARAVEL_API_URL=http://api.kiln.local:8000
LARAVEL_API_KEY=your-secret-key
LARAVEL_VALIDATION_ENABLED=1
LARAVEL_VALIDATION_TIMEOUT=5.0

# Node.js event consumer (will be enabled when Node service comes online)
NODEJS_EVENT_CONSUMER_ENABLED=0

# Per-tenant model adapters (future)
PER_TENANT_MODELS_ENABLED=0
MODELS_BASE_DIR=/app/detector/models/base
MODELS_TENANT_ADAPTERS_DIR=/app/detector/models/tenant_adapters

# Alerts
ALERT_ENABLED=1
ALERT_SERVICE=webhook
ALERT_WEBHOOK_URL=http://api.kiln.local:8000/api/alerts/webhook
```

### 1.4 API Call Example (Python Client)

```python
import httpx

async def call_detector_full():
    """Call the updated /detect/full endpoint"""
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "http://localhost:5000/detect/full",
            files={"file": open("frame.jpg", "rb")},
            params={
                "tenant_id": "riaz-industries",
                "kiln_id": "kiln-dhaka-01",
                "camera_id": "CAM-GATE-MAIN",
                "gate_id": "GATE-01",  # Optional
            },
        )
        result = response.json()
        print(f"Detection complete: {len(result['vehicles'])} vehicles")
        print("Events emitted to Redis → Node.js worker will validate")
```

---

## Part 2: Node.js Event Consumer

### 2.1 Event Schema (Redis Queue)

**Queue name:** `securityos_detection_events` (BullMQ compatible)

**Event structure:**
```json
{
  "event_id": "550e8400-e29b-41d4-a716-446655440000",
  "tenant_id": "riaz-industries",
  "kiln_id": "kiln-dhaka-01",
  "camera_id": "CAM-GATE-MAIN",
  "timestamp": "2025-06-05T14:32:15.123Z",
  "plate": "DHAKA-D-12-1234",
  "plate_norm": "DHAKAD121234",
  "sub_type": "Truck-Large",
  "load_status": "Full",
  "material": "Bricks",
  "gate_decision": "Pass",
  "overall_score": 0.92,
  "confidence": 0.89,
  "actual_percent": 92,
  "expected_percent": null,
  "source": "detector"
}
```

### 2.2 Node.js Worker Template

```javascript
// worker.js - Event consumer (BullMQ)
import Queue from 'bull';
import axios from 'axios';

const detectionQueue = new Queue('securityos_detection_events', {
  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: process.env.REDIS_PORT || 6379,
  },
});

// Process detection events
detectionQueue.process(async (job) => {
  const event = job.data;
  console.log(`[${event.kiln_id}] Processing event: ${event.event_id}`);

  try {
    // 1. Validate against Laravel API
    const validation = await validateWithLaravel({
      tenant_id: event.tenant_id,
      kiln_id: event.kiln_id,
      plate: event.plate_norm,
      vehicle_type: event.sub_type,
      load_status: event.load_status,
      material_type: event.material,
      actual_percent: event.actual_percent,
    });

    // 2. Check if validation passed
    if (validation.approved) {
      console.log(`✅ APPROVED: ${event.plate_norm}`);
      // Auto-approve in Laravel
      await updateEventStatus(event.event_id, 'approved', validation);
      return { status: 'approved', validation };
    } else {
      console.log(`⚠️  FLAGGED: ${event.plate_norm} - ${validation.mismatches.join(', ')}`);
      // Flag for admin review
      await createReviewTicket(event, validation);
      // Push alert
      await pushAlert(event, validation);
      return { status: 'flagged', validation };
    }

  } catch (error) {
    console.error(`❌ Error processing event: ${error.message}`);
    // Retry with exponential backoff
    throw error;
  }
});

// Helper: Call Laravel validation API
async function validateWithLaravel(data) {
  const response = await axios.post(
    `${process.env.LARAVEL_API_URL}/api/detect/validate`,
    data,
    {
      headers: {
        'X-API-Key': process.env.LARAVEL_API_KEY,
      },
      timeout: 5000,
    }
  );
  return response.data;
}

// Helper: Update event status in Laravel
async function updateEventStatus(eventId, status, validation) {
  await axios.patch(
    `${process.env.LARAVEL_API_URL}/api/detection-events/${eventId}`,
    { status, validation },
    {
      headers: { 'X-API-Key': process.env.LARAVEL_API_KEY },
    }
  );
}

// Helper: Create review ticket for mismatches
async function createReviewTicket(event, validation) {
  await axios.post(
    `${process.env.LARAVEL_API_URL}/api/review-tickets`,
    {
      event_id: event.event_id,
      tenant_id: event.tenant_id,
      kiln_id: event.kiln_id,
      camera_id: event.camera_id,
      plate: event.plate,
      ai_result: {
        vehicle: event.sub_type,
        load: event.load_status,
        material: event.material,
        confidence: event.confidence,
      },
      mismatches: validation.mismatches,
      gatepass_id: validation.gatepass_id,
      status: 'pending_review',
    },
    {
      headers: { 'X-API-Key': process.env.LARAVEL_API_KEY },
    }
  );
}

// Helper: Push alert to tenant
async function pushAlert(event, validation) {
  // Option A: Webhook to Laravel
  await axios.post(
    `${process.env.LARAVEL_API_URL}/api/alerts/webhook`,
    {
      event_id: event.event_id,
      tenant_id: event.tenant_id,
      kiln_id: event.kiln_id,
      alert_type: 'detection_flagged',
      message: `Vehicle flagged for review: ${event.plate_norm}`,
      mismatches: validation.mismatches,
      timestamp: new Date().toISOString(),
    },
    {
      headers: { 'X-API-Key': process.env.LARAVEL_API_KEY },
    }
  );

  // Option B: Push to Pusher for real-time UI
  if (process.env.PUSHER_ENABLED === '1') {
    const pusher = new Pusher({
      appId: process.env.PUSHER_APP_ID,
      key: process.env.PUSHER_APP_KEY,
      secret: process.env.PUSHER_SECRET,
      cluster: process.env.PUSHER_CLUSTER,
    });

    await pusher.trigger(`tenant-${event.tenant_id}`, 'detection.flagged', {
      kiln_id: event.kiln_id,
      event_id: event.event_id,
      plate: event.plate_norm,
      mismatches: validation.mismatches,
    });
  }
}

// Error handling
detectionQueue.on('failed', (job, err) => {
  console.error(`Job ${job.id} failed:`, err.message);
  // Implement dead-letter queue or metrics here
});

detectionQueue.on('completed', (job) => {
  console.log(`Job ${job.id} completed:`, job.returnvalue);
});

export default detectionQueue;
```

### 2.3 Docker Compose (Node.js + Redis)

```yaml
version: '3.8'

services:
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s

  detector:
    build:
      context: .
      dockerfile: detector/Dockerfile
    ports:
      - "5000:5000"
    environment:
      REDIS_URL: redis://redis:6379/0
      LARAVEL_API_URL: http://api:8000
      LARAVEL_API_KEY: ${LARAVEL_API_KEY}
    depends_on:
      redis:
        condition: service_healthy

  nodejs-worker:
    build:
      context: .
      dockerfile: nodejs/Dockerfile  # Your Node.js Dockerfile
    environment:
      REDIS_HOST: redis
      REDIS_PORT: 6379
      LARAVEL_API_URL: http://api:8000
      LARAVEL_API_KEY: ${LARAVEL_API_KEY}
      PUSHER_ENABLED: "1"
      PUSHER_APP_KEY: ${PUSHER_APP_KEY}
      PUSHER_CLUSTER: ${PUSHER_CLUSTER}
    depends_on:
      redis:
        condition: service_healthy

  api:
    image: your-laravel-app:latest  # Your Laravel Docker image
    ports:
      - "8000:8000"
    environment:
      DB_CONNECTION: mysql
      # ... other Laravel env vars

volumes:
  redis-data:
```

---

## Part 3: Laravel API Endpoints

### 3.1 Validation Endpoint

**POST** `/api/detect/validate`

Request:
```json
{
  "tenant_id": "riaz-industries",
  "kiln_id": "kiln-dhaka-01",
  "plate": "DHAKAD121234",
  "vehicle_sub_type": "Truck-Large",
  "load_status": "Full",
  "material_type": "Bricks",
  "actual_percent": 92,
  "timestamp": "2025-06-05T14:32:15.123Z"
}
```

Response:
```json
{
  "approved": false,
  "status": "flagged",
  "mismatches": [
    "load_mismatch",
    "material_mismatch"
  ],
  "gatepass_id": "gp-123456",
  "driver_id": "driver-789",
  "vehicle_id": "vehicle-456",
  "confidence": 0.85,
  "message": "Load status mismatch: AI=Full, Expected=Partial"
}
```

### 3.2 Review Ticket Endpoint

**POST** `/api/review-tickets`

Creates admin review task for mismatches.

### 3.3 Alert Webhook

**POST** `/api/alerts/webhook`

Receives alerts from Node.js worker (or Detector directly).

---

## Part 4: Database Schema (Laravel)

### Detection Events Table

```sql
CREATE TABLE detection_events (
  id UUID PRIMARY KEY,
  tenant_id VARCHAR(255) NOT NULL,
  kiln_id VARCHAR(255) NOT NULL,
  camera_id VARCHAR(255) NOT NULL,
  plate VARCHAR(255),
  plate_normalized VARCHAR(255),
  vehicle_type VARCHAR(100),
  load_status VARCHAR(50),
  material_type VARCHAR(100),
  ai_confidence FLOAT,
  gate_decision VARCHAR(50),
  validation_status VARCHAR(50),  -- 'approved', 'flagged', 'error'
  mismatches JSON,
  gatepass_id UUID,
  driver_id UUID,
  vehicle_id UUID,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (tenant_id) REFERENCES tenants(id),
  FOREIGN KEY (kiln_id) REFERENCES brick_kilns(id),
  FOREIGN KEY (gatepass_id) REFERENCES gatepasses(id),
  INDEX (tenant_id, kiln_id, created_at),
  INDEX (validation_status),
  INDEX (plate_normalized)
);

CREATE TABLE review_tickets (
  id UUID PRIMARY KEY,
  detection_event_id UUID NOT NULL,
  tenant_id VARCHAR(255) NOT NULL,
  kiln_id VARCHAR(255) NOT NULL,
  status VARCHAR(50),  -- 'pending_review', 'approved', 'corrected', 'rejected'
  reviewer_id UUID,
  ai_result JSON,
  corrections JSON,
  mismatches JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  resolved_at TIMESTAMP,
  
  FOREIGN KEY (detection_event_id) REFERENCES detection_events(id),
  FOREIGN KEY (tenant_id) REFERENCES tenants(id),
  FOREIGN KEY (reviewer_id) REFERENCES users(id),
  INDEX (status, created_at),
  INDEX (tenant_id, resolved_at)
);
```

---

## Part 5: Testing

### 5.1 Test Event Emission

```bash
# Send test detection to detector
curl -X POST \
  "http://localhost:5000/detect/full?tenant_id=test&kiln_id=test&camera_id=CAM-01" \
  -F "file=@test-frame.jpg"

# Check Redis queue
redis-cli LLEN securityos_detection_events
redis-cli LRANGE securityos_detection_events 0 0
```

### 5.2 Test Node.js Worker

```bash
# Start worker locally
node worker.js

# Push test event manually
redis-cli RPUSH securityos_detection_events '{
  "event_id": "test-1",
  "tenant_id": "test",
  "kiln_id": "test",
  "camera_id": "CAM-01",
  "plate": "TEST-D-01-001",
  "plate_norm": "TESTD01001",
  "sub_type": "Truck-Large",
  "load_status": "Full",
  "material": "Bricks",
  "gate_decision": "Pass",
  "overall_score": 0.9,
  "confidence": 0.85,
  "source": "detector"
}'

# Watch worker logs
```

### 5.3 Integration Test (Python)

```python
import asyncio
import httpx
import json
from redis import Redis

async def test_full_pipeline():
    """End-to-end test: detector → redis → expected event"""
    
    # Connect to Redis
    r = Redis(host='localhost', port=6379, decode_responses=True)
    initial_queue_len = r.llen('securityos_detection_events')
    
    # Call detector
    async with httpx.AsyncClient() as client:
        with open('test-frame.jpg', 'rb') as f:
            response = await client.post(
                'http://localhost:5000/detect/full',
                files={'file': f},
                params={
                    'tenant_id': 'test-org',
                    'kiln_id': 'test-kiln',
                    'camera_id': 'CAM-TEST',
                }
            )
    
    result = response.json()
    print(f"Detection result: {result['total_vehicles']} vehicles")
    
    # Check Redis queue
    await asyncio.sleep(1)  # Give emitter time to push
    new_queue_len = r.llen('securityos_detection_events')
    
    assert new_queue_len > initial_queue_len, "No events emitted!"
    
    # Verify event structure
    event_json = r.lpop('securityos_detection_events')
    event = json.loads(event_json)
    
    assert event['tenant_id'] == 'test-org'
    assert event['kiln_id'] == 'test-kiln'
    assert event['camera_id'] == 'CAM-TEST'
    assert 'event_id' in event
    assert 'timestamp' in event
    
    print("✅ Full pipeline test passed!")

asyncio.run(test_full_pipeline())
```

---

## Part 6: Deployment Checklist

- [ ] Update detector config.py with LARAVEL_API_URL + key
- [ ] Add httpx to requirements.txt
- [ ] Wire event emission in detect.py (copy from detect_full_updated.py)
- [ ] Set up Redis (Docker or managed service)
- [ ] Deploy Node.js worker with BullMQ
- [ ] Create detection_events + review_tickets tables in Laravel
- [ ] Implement /api/detect/validate endpoint in Laravel
- [ ] Test event emission (redis-cli LRANGE)
- [ ] Test Node.js worker consuming events
- [ ] Configure alerts (webhook or Pusher)
- [ ] Set up monitoring/logging for event pipeline

---

## Part 7: Monitoring & Debugging

### Redis Queue Status

```bash
# Queue depth
redis-cli LLEN securityos_detection_events

# Sample recent event
redis-cli LINDEX securityos_detection_events 0

# Monitor stream
redis-cli MONITOR | grep detection_events
```

### Detector Logs

```bash
docker logs -f brickify-detector | grep "\[emitter\]"
docker logs -f brickify-detector | grep "\[full\]"
```

### Node.js Worker Logs

```bash
docker logs -f nodejs-worker | grep "Processing event"
```

---

## Questions for Your Architecture?

1. **Tenant-specific models**: Ready to implement per-tenant adapters now, or later?
2. **Alert routing**: Webhook, Pusher, or something else?
3. **Dashboard**: UI for reviewing flagged detections?
4. **Feedback loop**: How does correction flow back into training?

