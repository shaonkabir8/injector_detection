# Code Changes Checklist - Event Emissions Wiring

## Files to Modify

### 1. `config.py` - Add new settings

**Status**: Copy from `config_updated.py`

Changes:
- Add Laravel API configuration (url, key, timeout)
- Add per-tenant model paths
- Add alert service settings
- Add event TTL config

**Minimal version** (if you don't want per-tenant models yet):
```python
# Add to bottom of config.py

# ── Laravel API Integration ─────────────────────────────────
laravel_api_url: str = os.environ.get("LARAVEL_API_URL", "http://localhost:8000")
laravel_api_key: str = os.environ.get("LARAVEL_API_KEY", "")
laravel_validation_enabled: bool = bool(os.environ.get("LARAVEL_VALIDATION_ENABLED", "1"))
laravel_validation_timeout: float = float(os.environ.get("LARAVEL_VALIDATION_TIMEOUT", "5.0"))

# ── Event TTL ───────────────────────────────────────────────
event_ttl: int = int(os.environ.get("EVENT_TTL", 86400))  # 24 hours

# ── Alerts ──────────────────────────────────────────────────
alert_enabled: bool = bool(os.environ.get("ALERT_ENABLED", "1"))
alert_service: str = os.environ.get("ALERT_SERVICE", "webhook")
alert_webhook_url: str = os.environ.get("ALERT_WEBHOOK_URL", "")
```

---

### 2. `modules/validation.py` - NEW FILE

**Status**: Create fresh

Copy entire file from `modules_validation.py`. This module:
- Calls Laravel API to validate detections
- Returns approval status + mismatches
- Handles retries + timeouts
- Non-blocking (fire-and-forget)

**Key exports**:
```python
class ValidationStatus(str, Enum):
    APPROVED = "approved"
    FLAGGED = "flagged"
    ERROR = "error"

class LaravelValidator:
    async def validate_detection(...) -> ValidationResult

async def validate_and_emit_event(...) -> bool
```

---

### 3. `requirements.txt` - Add new dependency

**Add**:
```
httpx>=0.24.0
```

---

### 4. `routers/detect.py` - Wire event emission into `/full` endpoint

**Step-by-step**:

#### 4.1 Add imports at top

```python
from fastapi import Query  # Add Query to existing imports
```

#### 4.2 Update function signature

**OLD:**
```python
@router.post("/full", response_model=FullDetectionResponse, ...)
async def detect_full(file: UploadFile = File(...)) -> FullDetectionResponse:
```

**NEW:**
```python
@router.post("/full", response_model=FullDetectionResponse, ...)
async def detect_full(
    file: UploadFile = File(..., description="Frame image"),
    tenant_id: str = Query(..., description="Tenant identifier"),
    kiln_id: str = Query(..., description="Kiln site ID"),
    camera_id: str = Query(..., description="Gate camera ID"),
    gate_id: Optional[str] = Query(None, description="Gate ID (optional)"),
) -> FullDetectionResponse:
```

#### 4.3 Update cache key (make tenant-aware)

**OLD:**
```python
cached = cache.get_result("full", data)
```

**NEW:**
```python
# Partition cache by tenant/kiln/camera
cache_key = f"result:full:{tenant_id}:{kiln_id}:{camera_id}:{_image_hash(data)}"
cached = cache.get(cache_key)
if cached:
    return FullDetectionResponse(**json.loads(cached))
```

And when setting:
```python
# OLD
cache.set_result("full", data, result.model_dump())

# NEW
import json
cache.setex(
    cache_key,
    900,  # 15 min TTL
    json.dumps(result.model_dump())
)
```

#### 4.4 Add event emission in the vehicle processing loop

After building `vehicle_results` list, add:

```python
# ── Emit events for each vehicle ───────────────────────────┐
# Models E → F → G → H → I per vehicle
vehicle_results: list[VehicleResult] = []
for v in all_vehicles:
    vr = _process_vehicle(
        image, v, raw_detections, model_available, quality,
        include_validation=False,
    )
    vehicle_results.append(vr)

    # ┌─ EMIT EVENT ──────────────────────────────────┐
    try:
        from modules.event_emitter import emit_from_vehicle_result
        event_pushed = emit_from_vehicle_result(
            vr,
            tenant_id=tenant_id,
            camera_id=camera_id,
        )
        if event_pushed:
            logger.info(
                f"[full] Event emitted — tenant={tenant_id} "
                f"vehicle={vr.vehicle.vehicle_sub_type.value if vr.vehicle else 'unknown'}"
            )
    except Exception as exc:
        logger.error(f"[full] Event emission error: {exc}")
        # Don't fail the entire request
```

**Note:** This is non-blocking. If Redis is down, detection still succeeds but events won't queue.

---

### 5. Optional: `routers/detect.py` - Add events list endpoint

Add new endpoint to see recent events:

```python
@router.get(
    "/events/{tenant_id}/{kiln_id}",
    summary="List recent detection events",
)
async def list_recent_events(
    tenant_id: str = Query(...),
    kiln_id: str = Query(...),
    limit: int = Query(20, ge=1, le=100),
) -> dict:
    """Get recent detection events for a tenant/kiln from Redis queue"""
    try:
        from modules.cache import _get_client
        r = _get_client()
        if not r:
            return {"error": "Redis unavailable"}

        # Retrieve events from queue
        queue_key = f"{tenant_id}:{kiln_id}:events"
        events = []
        
        for event_str in r.lrange(queue_key, 0, limit - 1):
            try:
                events.append(json.loads(event_str))
            except:
                pass

        return {
            "tenant_id": tenant_id,
            "kiln_id": kiln_id,
            "total_queued": r.llen(queue_key),
            "recent": events,
        }
    except Exception as exc:
        logger.error(f"[events] Error: {exc}")
        return {"error": str(exc)}
```

---

## Environment Variables to Set

**In `.env` or docker-compose environment**:

```bash
# Redis (must be set for events to work)
REDIS_URL=redis://redis:6379/0

# Laravel validation
LARAVEL_API_URL=http://api.kiln.local:8000
LARAVEL_API_KEY=your-secret-api-key
LARAVEL_VALIDATION_ENABLED=1
LARAVEL_VALIDATION_TIMEOUT=5.0

# Events
EVENT_TTL=86400

# Alerts
ALERT_ENABLED=1
ALERT_SERVICE=webhook
ALERT_WEBHOOK_URL=http://api.kiln.local:8000/api/alerts/webhook
```

---

## Testing Changes

### 1. Local Test

```bash
# Start detector with Redis
docker-compose up -d redis detector

# Send test image
curl -X POST \
  "http://localhost:5000/detect/full?tenant_id=test&kiln_id=test&camera_id=CAM-01" \
  -F "file=@test-frame.jpg"

# Check Redis queue
docker exec -it redis-container redis-cli
> LLEN securityos_detection_events
(integer) 1
> LRANGE securityos_detection_events 0 0
> (prints event JSON)
```

### 2. Check Logs

```bash
# Look for event emission logs
docker logs detector | grep "\[emitter\]"
docker logs detector | grep "\[full\]"
```

### 3. Python Integration Test

```python
import redis
import json
import httpx
import asyncio

async def test():
    r = redis.Redis(host='localhost', port=6379, decode_responses=True)
    
    # Clear queue
    r.delete('securityos_detection_events')
    
    # Call detector
    async with httpx.AsyncClient() as client:
        with open('test.jpg', 'rb') as f:
            response = await client.post(
                'http://localhost:5000/detect/full',
                files={'file': f},
                params={
                    'tenant_id': 'test',
                    'kiln_id': 'test',
                    'camera_id': 'CAM-01',
                }
            )
    
    print(f"Detection: {response.status_code}")
    await asyncio.sleep(1)
    
    # Check event
    event_str = r.lpop('securityos_detection_events')
    if event_str:
        event = json.loads(event_str)
        print(f"✅ Event emitted: {event['event_id']}")
        print(f"   tenant: {event['tenant_id']}")
        print(f"   kiln: {event.get('kiln_id', 'N/A')}")
        print(f"   camera: {event['camera_id']}")
    else:
        print("❌ No event in queue!")

asyncio.run(test())
```

---

## File Dependencies

```
config.py
  └─ REQUIRES: LARAVEL_API_URL, LARAVEL_API_KEY

modules/validation.py (NEW)
  └─ REQUIRES: httpx library
  └─ USES: config.py (settings)

routers/detect.py
  └─ IMPORTS: modules.event_emitter
  └─ IMPORTS: modules.validation (optional for future)
  └─ USES: config.py (for cache, validation settings)

modules/event_emitter.py (EXISTING - no changes)
  └─ Uses Redis from modules.cache

requirements.txt
  └─ ADD: httpx>=0.24.0
```

---

## Rollout Plan

### Phase 1: Local Development
- [ ] Copy config_updated.py → config.py
- [ ] Copy modules_validation.py → modules/validation.py
- [ ] Update routers/detect.py with tenant params + event emission
- [ ] Add httpx to requirements.txt
- [ ] Test locally with redis-cli

### Phase 2: Docker Staging
- [ ] Build detector image with changes
- [ ] Stand up Redis container
- [ ] Test with integration test script
- [ ] Verify events in Redis queue

### Phase 3: Integration with Node.js
- [ ] Deploy Node.js worker (see worker.js template)
- [ ] Set up BullMQ queue listener
- [ ] Test end-to-end: detector → redis → node → validation → alert

### Phase 4: Production
- [ ] Set all environment variables in production
- [ ] Deploy detector with changes
- [ ] Deploy Node.js worker
- [ ] Monitor Redis queue depth + processing lag
- [ ] Set up alerts for queue backlog

---

## Troubleshooting

### "No events in Redis queue"

1. Check detector logs:
   ```bash
   docker logs detector | grep emitter
   ```

2. Verify Redis connection:
   ```bash
   docker logs detector | grep "cache.*Redis"
   ```

3. Check REDIS_URL is set:
   ```bash
   docker logs detector | grep "REDIS_URL"
   ```

### "Redis: Connection refused"

- Ensure Redis container is running: `docker ps | grep redis`
- Check REDIS_URL format: `redis://redis:6379/0`
- For local: `redis://localhost:6379/0`

### "Events not being consumed by Node.js"

1. Check BullMQ is connected:
   ```javascript
   console.log(detectionQueue.client.status);
   ```

2. Check queue name matches:
   ```javascript
   // Must be exactly: 'securityos_detection_events'
   new Queue('securityos_detection_events', { redis: { ... } })
   ```

3. Verify Redis keys:
   ```bash
   redis-cli KEYS "*detection*"
   ```

---

## Questions?

- **Tenant models**: When to implement per-kiln adapters?
- **Performance**: Worry about queue lag with 100+ cameras?
- **Fallback**: What if Laravel API is down? (Currently: flag all for review)

