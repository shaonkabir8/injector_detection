"""
UPDATED detect_full endpoint with event emission + tenant/camera context

CHANGES from original:
  1. Accept tenant_id, kiln_id, camera_id as query params
  2. Add cache key partitioning by tenant/camera
  3. Call emit_from_vehicle_result() after pipeline completes
  4. Structured event → Redis → Node worker
"""

from fastapi import APIRouter, File, UploadFile, HTTPException, Query, status
from pydantic import BaseModel, Field
from typing import Optional
import logging

logger = logging.getLogger(__name__)
router = APIRouter(tags=["detection"])


# ── Updated Request Model ────────────────────────────────────────────────────

class DetectionRequest(BaseModel):
    """Request context with tenant + camera info"""
    tenant_id: str = Field(..., min_length=1, description="Tenant/Kiln identifier")
    kiln_id: str = Field(..., min_length=1, description="Brick kiln site identifier")
    camera_id: str = Field(..., min_length=1, description="Camera identifier at gate")
    gate_id: Optional[str] = None  # Optional for future multi-gate support


# ── Updated Full Pipeline Endpoint ──────────────────────────────────────────

@router.post(
    "/full",
    response_model=FullDetectionResponse,
    summary="Full 9-model pipeline — with event emission",
    description=(
        "Runs all 9 models on every primary vehicle found in the image.\n\n"
        "**NEW:** Automatically emits detection events to Redis queue "
        "for downstream validation and dataset collection.\n\n"
        "**Required parameters:**\n"
        "- `tenant_id`: Your organization/kiln identifier\n"
        "- `kiln_id`: Specific brick kiln site\n"
        "- `camera_id`: Gate camera identifier\n\n"
        "Events are partitioned by tenant/kiln/camera for isolation."
    ),
)
async def detect_full(
    file: UploadFile = File(
        ...,
        description="Frame image (JPEG/PNG, ≤20MB)"
    ),
    tenant_id: str = Query(
        ...,
        description="Tenant identifier (e.g., 'riaz-industries')"
    ),
    kiln_id: str = Query(
        ...,
        description="Kiln site ID (e.g., 'kiln-dhaka-01')"
    ),
    camera_id: str = Query(
        ...,
        description="Gate camera ID (e.g., 'CAM-GATE-MAIN')"
    ),
    gate_id: Optional[str] = Query(
        None,
        description="Gate ID if multi-gate support (optional)"
    ),
) -> FullDetectionResponse:
    """
    Full 9-model pipeline with automatic event emission.

    Flow:
      1. Read image from upload
      2. Check cache (partitioned by tenant/kiln/camera/image_hash)
      3. Run quality check (Model A)
      4. Detect vehicles (Models B + C + D) — all vehicles
      5. Process each vehicle (Models E → F → G → H → I)
      6. Emit detection event to Redis queue
         ├─ Destination: tenant.kiln.camera.detect queue
         ├─ Consumers: Node.js validation service + Dataset workers
         └─ Event includes vehicle/load/material/plate/gate results
      7. Return response to client (non-blocking)

    Event structure (pushed to Redis):
    {
      "event_id": "uuid",
      "tenant_id": "kiln-owner",
      "kiln_id": "dhaka-01",
      "camera_id": "CAM-GATE-01",
      "timestamp": "2025-06-05T14:32:00Z",
      "plate": "DHAKA-D-12-1234",
      "plate_norm": "DHAKAD121234",
      "sub_type": "Truck-Large",
      "load_status": "Full",
      "material": "Bricks",
      "gate_decision": "Pass",
      "overall_score": 0.92,
      "confidence": 0.89,
      "source": "detector"
    }
    """
    data = await file.read()

    # ── Cache check (tenant/camera aware) ──────────────────────────────────
    cache_key = f"result:full:{tenant_id}:{kiln_id}:{camera_id}:{_image_hash(data)}"
    cached = cache.get(cache_key)
    if cached:
        logger.info(
            f"[full] Cache hit — tenant={tenant_id} kiln={kiln_id} camera={camera_id}"
        )
        return FullDetectionResponse(**json.loads(cached))

    image = _read_image(data)

    # Model A — once per image
    quality = check_image_quality(image)

    # Models B + C + D — detect ALL primary vehicles
    _, all_vehicles, model_available = detect_vehicles(image)
    raw_detections, _ = run_raw_yolo(image) if model_available else ([], False)

    if not all_vehicles:
        logger.info(
            f"[full] No vehicles detected — tenant={tenant_id} kiln={kiln_id}"
        )
        result = FullDetectionResponse(
            success=True,
            model_available=model_available,
            image_quality=quality,
            vehicles=[],
            total_vehicles=0,
        )
        cache.setex(cache_key, 900, json.dumps(result.model_dump()))
        return result

    # ── Models E → F → G → H → I per vehicle ──────────────────────────────
    vehicle_results: list[VehicleResult] = []
    for v in all_vehicles:
        vr = _process_vehicle(
            image, v, raw_detections, model_available, quality,
            include_validation=False,
        )
        vehicle_results.append(vr)

        # ┌─ EMIT EVENT FOR EACH VEHICLE ────────────────────────────────────┐
        # │ Non-blocking: fire-and-forget to Redis                           │
        # │ Node worker will consume and validate against Laravel API        │
        # └──────────────────────────────────────────────────────────────────┘
        try:
            from modules.event_emitter import emit_from_vehicle_result
            event_pushed = emit_from_vehicle_result(
                vr,
                tenant_id=tenant_id,
                camera_id=camera_id,
            )
            if event_pushed:
                logger.info(
                    f"[full] Event emitted — tenant={tenant_id} "
                    f"vehicle={vr.vehicle.vehicle_sub_type.value if vr.vehicle else 'unknown'}"
                )
            else:
                logger.warning(
                    f"[full] Event emission failed (Redis unavailable?) "
                    f"— continuing anyway"
                )
        except Exception as exc:
            logger.error(f"[full] Error emitting event: {exc}")
            # Don't fail the entire request if event emission fails
            # Detection already completed successfully

    logger.info(
        f"[full] Completed — tenant={tenant_id} kiln={kiln_id} "
        f"vehicles={len(vehicle_results)} quality={quality.quality.value}"
    )

    # Build response (backward compatible)
    first = vehicle_results[0] if vehicle_results else None
    result = FullDetectionResponse(
        success=True,
        model_available=model_available,
        image_quality=quality,
        vehicles=vehicle_results,
        total_vehicles=len(vehicle_results),
        vehicle=first.vehicle if first else None,
        cargo_segmentation=first.cargo_segmentation if first else None,
        load=first.load if first else None,
        material=first.material if first else None,
        plate=first.plate if first else None,
        gate=first.gate if first else None,
    )

    # Cache result (with TTL)
    cache.setex(
        cache_key,
        900,  # 15 min TTL
        json.dumps(result.model_dump())
    )

    return result


# ── Queue Status Endpoint ──────────────────────────────────────────────────

@router.get(
    "/events/{tenant_id}/{kiln_id}",
    summary="List recent events for tenant/kiln",
    description=(
        "Returns the 20 most recent detection events emitted by this tenant.\n\n"
        "Useful for UI dashboards to show recent detections without polling /full."
    ),
)
async def list_recent_events(
    tenant_id: str = Query(..., description="Tenant identifier"),
    kiln_id: str = Query(..., description="Kiln identifier"),
    limit: int = Query(20, ge=1, le=100),
) -> dict:
    """
    List recent events for a tenant/kiln from Redis queue.
    
    Response:
    {
      "tenant_id": "...",
      "kiln_id": "...",
      "total_events": 125,
      "recent": [
        { event_id, camera_id, plate, load_status, timestamp, ... }
      ]
    }
    """
    try:
        from modules.cache import _get_client
        r = _get_client()
        if not r:
            return {"error": "Redis unavailable"}

        # Retrieve event IDs from tenant-scoped queue
        queue_key = f"{tenant_id}:{kiln_id}:detect"
        events = []

        # Example: simple implementation (BullMQ has more features)
        # In production, use BullMQ for priority, retries, etc.
        event_ids = r.lrange(queue_key, 0, limit - 1)
        
        for event_id in event_ids:
            event_data = r.get(f"event:{event_id}")
            if event_data:
                events.append(json.loads(event_data))

        return {
            "tenant_id": tenant_id,
            "kiln_id": kiln_id,
            "total_queued": r.llen(queue_key),
            "recent": events,
        }

    except Exception as exc:
        logger.error(f"[events] Failed to list events: {exc}")
        return {
            "error": str(exc),
            "tenant_id": tenant_id,
            "kiln_id": kiln_id,
        }
